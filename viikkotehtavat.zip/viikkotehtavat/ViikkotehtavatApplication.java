package com.example.viikkotehtavat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViikkotehtavatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViikkotehtavatApplication.class, args);
	}

}
